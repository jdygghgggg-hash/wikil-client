package net.mixin;

import net.client.ModManager;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public class VelocityMixin {
    @Inject(method = "onEntityVelocityUpdate", at = @At("HEAD"), cancellable = true)
    private void onVelocity(EntityVelocityUpdateS2CPacket packet, CallbackInfo ci) {
        // Добавилась проверка: если модуль ВЫКЛЮЧЕН в меню, то отдача работает как обычно
        if (!ModManager.velocityEnabled) return;

        if (MinecraftClient.getInstance().player != null && 
            packet.getId() == MinecraftClient.getInstance().player.getId()) {
            ci.cancel();
        }
    }
}
