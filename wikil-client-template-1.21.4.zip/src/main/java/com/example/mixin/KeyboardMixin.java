package com.example.mixin;

import com.example.ClickGuiScreen;
import net.minecraft.client.Keyboard;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Keyboard.class)
public class KeyboardMixin {
    @Inject(method = "onKey", at = @At("HEAD"))
    private void onKeyEvent(long window, int key, int scancode, int action, int modifiers, CallbackInfo ci) {
        MinecraftClient mc = MinecraftClient.getInstance();
        
        // Открытие меню на Правый Шифт (RSHIFT) в PojavLauncher
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT && action == 1 && mc.currentScreen == null && mc.player != null) {
            mc.execute(() -> mc.setScreen(new ClickGuiScreen()));
        }
    }
}
