package com.example.mixin;


import net.client.ModManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MinecraftClient.class)
public class TriggerBotMixin {
    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        // Добавилась проверка: если триггер выключен в GUI, код дальше не идет
        if (!ModManager.triggerBotEnabled) return;

        MinecraftClient mc = (MinecraftClient)(Object)this;
        if (mc.player != null && mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.ENTITY) {
            if (mc.player.getAttackCooldownProgress(0.0f) >= 1.0f) {
                EntityHitResult hit = (EntityHitResult) mc.crosshairTarget;
                if (mc.interactionManager != null) {
                    mc.interactionManager.attackEntity(mc.player, hit.getEntity());
                    mc.player.swingHand(Hand.MAIN_HAND);
                }
            }
        }
    }
}
