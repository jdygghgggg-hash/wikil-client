package com.example;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

public class ClickGuiScreen extends Screen {
    public ClickGuiScreen() {
        super(Text.literal("wikil client GUI"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Рисуем задний полупрозрачный фон игры, пока открыто меню
        this.renderBackground(context, mouseX, mouseY, delta);

        // Начальные координаты нашего окошка меню на экране телефона
        int x = 50;
        int y = 50;

        // Рисуем темную плашку самого меню (длина 150, высота 100)
        context.fill(x, y, x + 150, y + 100, 0xFF202020); 
        // Красивый неоново-розовый цвет для названия твоего софта wikil client (0xFF00FF)
        context.drawText(this.textRenderer, "wikil client", x + 10, y + 10, 0xFF00FF, true);

        // Кнопка модуля Velocity (Зеленая если ON, Красная если OFF)
        int velColor = ModManager.velocityEnabled ? 0x00FF00 : 0xFF0000;
        context.fill(x + 10, y + 30, x + 140, y + 50, 0xFF353535);
        context.drawText(this.textRenderer, "Velocity: " + (ModManager.velocityEnabled ? "ON" : "OFF"), x + 15, y + 36, velColor, false);

        // Кнопка модуля TriggerBot (Зеленая если ON, Красная если OFF)
        int trigColor = ModManager.triggerBotEnabled ? 0x00FF00 : 0xFF0000;
        context.fill(x + 10, y + 60, x + 140, y + 80, 0xFF353535);
        context.drawText(this.textRenderer, "TriggerBot: " + (ModManager.triggerBotEnabled ? "ON" : "OFF"), x + 15, y + 66, trigColor, false);

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int x = 50;
        int y = 50;

        // Отслеживаем нажатие пальцем по кнопке Velocity в PojavLauncher
        if (mouseX >= x + 10 && mouseX <= x + 140 && mouseY >= y + 30 && mouseY <= y + 50) {
            ModManager.toggleVelocity(); // Переключаем ВКЛ/ВЫКЛ
            return true;
        }

        // Отслеживаем нажатие пальцем по кнопке TriggerBot
        if (mouseX >= x + 10 && mouseX <= x + 140 && mouseY >= y + 60 && mouseY <= y + 80) {
            ModManager.toggleTriggerBot(); // Переключаем ВКЛ/ВЫКЛ
            return true;
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean shouldPause() {
        return false; // Чтобы во время открытия меню игра на сервере не застывала
    }
}
